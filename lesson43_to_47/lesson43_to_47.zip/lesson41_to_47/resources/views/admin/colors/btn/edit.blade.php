<a href="{{ aurl('colors/'.$id.'/edit') }}" class="btn btn-info"><i class="fa fa-edit"></i></a>
