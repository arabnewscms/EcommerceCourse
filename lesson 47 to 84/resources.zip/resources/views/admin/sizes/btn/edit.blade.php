<a href="{{ aurl('sizes/'.$id.'/edit') }}" class="btn btn-info"><i class="fa fa-edit"></i></a>
