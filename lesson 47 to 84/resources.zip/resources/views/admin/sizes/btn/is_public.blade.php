{{ trans('admin.'.$is_public) }}
