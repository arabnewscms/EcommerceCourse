<span style="width:25px;height:25px;background: {{ $color }};display:block;"></span>
