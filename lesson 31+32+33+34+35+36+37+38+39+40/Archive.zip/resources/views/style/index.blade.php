@include('style.layouts.header')
@include('style.layouts.navbar')
@include('style.layouts.menu')
@include('style.layouts.message')


@yield('content')



@include('style.layouts.footer')